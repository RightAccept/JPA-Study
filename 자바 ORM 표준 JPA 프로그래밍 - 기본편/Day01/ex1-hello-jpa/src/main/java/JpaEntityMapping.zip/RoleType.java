package JpaEntityMapping;

public enum RoleType {
    USER, ADMIN
}
