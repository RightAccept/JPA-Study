package JpaEntityMapping;

public class JpaEntityMapping1_introduce {
    // 객체와 테이블 매핑 : @Entity, @Table
    // 필드와 컬럼 매핑 : @Column
    // 기본 키 매핑 : @Id
    // 연관관계 매핑 : @ManyToOne, @JoinColumn
}
